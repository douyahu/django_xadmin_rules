#!D:\PyCharm 2017.1.4\django_xadmin_rules\shopvev\Scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
