

default_app_config = 'app_oracle.apps.AppOracleConfig'
