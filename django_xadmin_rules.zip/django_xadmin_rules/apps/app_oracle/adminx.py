from django.contrib import admin

# Register your models here.
import xadmin
from app_oracle.models import Student


class StudentAdmin(object):
    # 不显示字段
    exclude = ['id']
    pass


xadmin.sites.site.register(Student, StudentAdmin)
