from django.apps import AppConfig


class AppOracleConfig(AppConfig):
    name = 'app_oracle'
    verbose_name = 'Oracle模块'
    orderIndex_ = 1
